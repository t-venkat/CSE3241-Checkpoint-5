package osu.cse3241;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * <h1>CSE3241 Introduction to Database Systems - Sample Java application.</h1>
 *
 * <p>
 * Sample app to be used as guidance and a foundation for students of CSE3241
 * Introduction to Database Systems at The Ohio State University.
 * </p>
 *
 * <h2>!!! - Vulnerable to SQL injection - !!!</h2>
 * <p>
 * Correct the code so that it is not vulnerable to a SQL injection attack.
 * ("Parameter substitution" is the usual way to do this.)
 * </p>
 *
 * <p>
 * Class is written in Java SE 8 and in a procedural style. Implement a
 * constructor if you build this app out in OOP style.
 * </p>
 * <p>
 * Modify and extend this app as necessary for your project.
 * </p>
 *
 * <h2>Language Documentation:</h2>
 * <ul>
 * <li><a href="https://docs.oracle.com/javase/8/docs/">Java SE 8</a></li>
 * <li><a href="https://docs.oracle.com/javase/8/docs/api/">Java SE 8
 * API</a></li>
 * <li><a href=
 * "https://docs.oracle.com/javase/8/docs/technotes/guides/jdbc/">Java JDBC
 * API</a></li>
 * <li><a href="https://www.sqlite.org/docs.html">SQLite</a></li>
 * <li><a href="http://www.sqlitetutorial.net/sqlite-java/">SQLite Java
 * Tutorial</a></li>
 * </ul>
 *
 * <h2>MIT License</h2>
 *
 * <em>Copyright (c) 2019 Leon J. Madrid, Jeff Hachtel</em>
 *
 * <p>
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * </p>
 *
 *
 * @author Leon J. Madrid (madrid.1), Jeff Hachtel (hachtel.5)
 *
 */

public class CSE3241app {

    /**
     * The database file name.
     *
     * Make sure the database file is in the root folder of the project if you
     * only provide the name and extension.
     *
     * Otherwise, you will need to provide an absolute path from your C: drive
     * or a relative path from the folder this class is in.
     */
    private static String DATABASE = "DBLibrary.db";

    /**
     * The query statement to be executed.
     *
     * Remember to include the semicolon at the end of the statement string.
     * (Not all programming languages and/or packages require the semicolon
     * (e.g., Python's SQLite3 library))
     */
    private static String sqlStatement = "SELECT * FROM Album;";
    private static String selectArtistStatement = "SELECT StageName, FName, LName FROM ARTIST, PEOPLE WHERE ARTIST.StageName=? AND ARTIST.PersonID=PEOPLE.PersonID;";
    private static String addPeople = "INSERT INTO PEOPLE VALUES (?, ?, ?);";
    private static String addArtist = "INSERT INTO ARTIST VALUES (?, ?, ?);";
    private static String editArtistFName = "UPDATE PEOPLE SET FName = ? WHERE FName = ? AND LName = ?;";
    private static String editArtistLName = "UPDATE PEOPLE SET LName = ? WHERE FName = ? AND LName = ?";
    private static String editArtistStageName = "UPDATE ARTIST SET StageName = ? WHERE StageName = ?;";
    private static String orderMovive = "INSERT INTO ORDERS VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);";
    private static String reportOne = "SELECT Title FROM ARTIST, ALBUM, TRACK, TRACKLIST WHERE StageName = ? AND ARTIST.PersonID = ALBUM.ArtistID  AND ALBUM.ISRC=TRACKLIST.AlbumISRC  AND TRACKLIST.TrackISRC=TRACK.TrackISRC AND TRACK.Year<?;";
    private static String reportTwo = "SELECT COUNT(ISRC) FROM ALBUM, CHECKOUTS WHERE LibraryCardNum = ? AND  ALBUM.InvID = CHECKOUTS.InvID;";
    private static String reportFive = "SELECT COUNT(EIDR), LibraryCardNum FROM MOVIE, CHECKOUTS WHERE MOVIE.InvID = CHECKOUTS.InvID GROUP BY CHECKOUTS.LibraryCardNum ORDER BY DESC LIMIT 1;";

    /**
     * Connects to the database if it exists, creates it if it does not, and
     * returns the connection object.
     *
     * @param databaseFileName
     *            the database file name
     * @return a connection object to the designated database
     */
    public static Connection initializeDB(String databaseFileName) {
        /**
         * The "Connection String" or "Connection URL".
         *
         * "jdbc:sqlite:" is the "subprotocol". (If this were a SQL Server
         * database it would be "jdbc:sqlserver:".)
         */
        String url = "jdbc:sqlite:" + databaseFileName;
        Connection conn = null; // If you create this variable inside the Try block it will be out of scope
        try {
            conn = DriverManager.getConnection(url);
            if (conn != null) {
                // Provides some positive assurance the connection and/or creation was successful.
                DatabaseMetaData meta = conn.getMetaData();
                System.out
                        .println("The driver name is " + meta.getDriverName());
                System.out.println(
                        "The connection to the database was successful.");
            } else {
                // Provides some feedback in case the connection failed but did not throw an exception.
                System.out.println("Null Connection");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            System.out
                    .println("There was a problem connecting to the database.");
        }
        return conn;
    }

    /**
     * Queries the database and prints the results.
     *
     * @param conn
     *            a connection object
     * @param sql
     *            a SQL statement that returns rows This query is written with
     *            the Statement class, typically used for static SQL SELECT
     *            statements
     */
    public static void sqlQuery(Connection conn, String sql) {
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            Scanner keyboard = new Scanner(System.in);
            System.out.println(
                    "What is the stagename of the artist you would like to find?");
            String stageName = keyboard.nextLine();
            stmt.setString(1, stageName);

            ResultSet rs = stmt.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();
            if (!(rs.next())) { //Checks to see if Artist is in the DB
                System.out.println("Artist is not in the Database :(");
            } else {
                for (int i = 1; i <= columnCount; i++) {
                    String value = rsmd.getColumnName(i);
                    System.out.print(value);
                    if (i < columnCount) {
                        System.out.print(",  ");
                    }
                }
                System.out.print("\n");

                do {
                    for (int i = 1; i <= columnCount; i++) {
                        String columnValue = rs.getString(i);
                        System.out.print(columnValue);
                        if (i < columnCount) {
                            System.out.print(",  ");
                        }
                    }
                    System.out.print("\n");
                } while (rs.next());

            }
            keyboard.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void sqlAddArtist(Connection conn) {
        try {
            Scanner keyboard = new Scanner(System.in);
            PreparedStatement stmtPeople = conn.prepareStatement(addPeople);
            PreparedStatement stmtArtist = conn.prepareStatement(addArtist);
            System.out.println("Enter the Person ID: ");
            int personId = keyboard.nextInt();
            keyboard.nextLine();
            System.out.println("Enter the First Name of the Artist: ");
            String fName = keyboard.nextLine();
            System.out.println("Enter the Last Name of the Artist: ");
            String lName = keyboard.nextLine();
            System.out.println("Enter the Stage Name of the Artist: ");
            String stageName = keyboard.nextLine();
            System.out.println("Enter the SearchID for the Artist");
            int searchId = keyboard.nextInt();
            keyboard.nextLine();

            stmtPeople.setInt(1, personId);
            stmtPeople.setString(2, fName);
            stmtPeople.setString(3, lName);
            stmtArtist.setInt(1, personId);
            stmtArtist.setInt(2, searchId);
            stmtArtist.setString(3, stageName);

            int peopleRow = stmtPeople.executeUpdate();
            int artistRow = stmtArtist.executeUpdate();
            System.out.println("Row added in PEOPLE table: " + peopleRow);
            System.out.println("Row added in ARTIST table: " + artistRow);

            keyboard.close();

        } catch (SQLException e) {
            System.out.println("Error when trying to add Artist to DB");
            System.out.println(e.getMessage());
        }

    }

    private static void sqlEditArtist(Connection conn) {
        try {
            Scanner keyboard = new Scanner(System.in);
            String optionResponse = "";
            while (!(optionResponse.equals("a") || optionResponse.equals("b")
                    || optionResponse.equals("c"))) {
                System.out.println(
                        "Would you like to edit:\na. First Name\nb. Last Name\nc. Stage Name");
                optionResponse = keyboard.nextLine();
            }

            if (optionResponse.equals("a")) {
                System.out.println(
                        "What is the First Name of the Arist you would like to edit?");
                String fName = keyboard.nextLine();
                System.out.println(
                        "What is the Last Name of the Artist you would like to edit?");
                String lName = keyboard.nextLine();
                System.out.println("What is the NEW First Name of the Artist?");
                String newFName = keyboard.nextLine();
                PreparedStatement stmt = conn.prepareStatement(editArtistFName);
                stmt.setString(1, newFName);
                stmt.setString(2, fName);
                stmt.setString(3, lName);
                stmt.executeUpdate();

            } else if (optionResponse.equals("b")) {
                System.out.println(
                        "What is the First Name of the Arist you would like to edit?");
                String fName = keyboard.nextLine();
                System.out.println(
                        "What is the Last Name of the Artist you would like to edit?");
                String lName = keyboard.nextLine();
                System.out.println("What is the NEW Last Name of the Artist?");
                String newLName = keyboard.nextLine();
                PreparedStatement stmt = conn.prepareStatement(editArtistLName);
                stmt.setString(1, newLName);
                stmt.setString(2, fName);
                stmt.setString(3, lName);
                stmt.executeUpdate();
            } else {
                PreparedStatement stmt = conn
                        .prepareStatement(editArtistStageName);
                System.out.println(
                        "What is the Stage Name of the Artist you would like to edit?");
                String stageName = keyboard.nextLine();
                System.out.println("Enter the NEW Stage Name of the Artist: ");
                String newStageName = keyboard.nextLine();
                stmt.setString(1, newStageName);
                stmt.setString(2, stageName);
                stmt.executeUpdate();
            }

            keyboard.close();

        } catch (SQLException e) {
            System.out.println("Error when trying to edit Artist to DB");
            System.out.println(e.getMessage());
        }
    }

    private static void sqlOrderMovie(Connection conn) {
        try {
            Scanner keyboard = new Scanner(System.in);
            System.out.println("What is the Order Number?");
            int orderSN = keyboard.nextInt();
            keyboard.nextLine();
            System.out.println("What is the title of the Movie to order?");
            String title = keyboard.nextLine();
            System.out.println("What is the Year the movie was released in?");
            int year = keyboard.nextInt();
            keyboard.nextLine();
            System.out.println("How many electronic copies are being ordered?");
            int eCopies = keyboard.nextInt();
            keyboard.nextLine();
            System.out.println("How many physical copies are being ordered?");
            int pCopies = keyboard.nextInt();
            keyboard.nextLine();
            System.out.println("What is the price?");
            int price = keyboard.nextInt();
            keyboard.nextLine();
            System.out.println(
                    "What is the date the movie was ordered (MM/DD/YYYY)?");
            String date = keyboard.nextLine();
            System.out.println(
                    "What is the Employee ID of the Employee submitting the order?");
            int empID = keyboard.nextInt();
            keyboard.nextLine();
            PreparedStatement stmt = conn.prepareStatement(orderMovive);
            stmt.setInt(1, orderSN);
            stmt.setString(2, "Movie");
            stmt.setString(3, title);
            stmt.setInt(4, year);
            stmt.setInt(5, eCopies);
            stmt.setInt(6, pCopies);
            stmt.setInt(7, price);
            stmt.setString(8, date);
            stmt.setInt(9, empID);
            stmt.executeUpdate();

            keyboard.close();

        } catch (SQLException e) {
            System.out.println("Error when trying to movie");
            System.out.println(e.getMessage());
        }

    }

    private static void tracksByArtist(Connection conn) {
        try {
            Scanner keyboard = new Scanner(System.in);
            System.out.println(
                    "What is the Stage Name of the artist for this report?");
            String stageName = keyboard.nextLine();
            System.out.println("What is the Year for this report?");
            int year = keyboard.nextInt();
            keyboard.nextLine();

            PreparedStatement stmt = conn.prepareStatement(reportOne);
            stmt.setString(1, stageName);
            stmt.setInt(2, year);

            ResultSet rs = stmt.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                String value = rsmd.getColumnName(i);
                System.out.print(value);
                if (i < columnCount) {
                    System.out.print(",  ");
                }
            }
            System.out.print("\n");
            while (rs.next()) {
                for (int i = 1; i <= columnCount; i++) {
                    String columnValue = rs.getString(i);
                    System.out.print(columnValue);
                    if (i < columnCount) {
                        System.out.print(",  ");
                    }
                }
                System.out.print("\n");
            }

            keyboard.close();

        } catch (SQLException e) {
            System.out.println("Error when trying to execute report");
            System.out.println(e.getMessage());
        }
    }

    private static void numberAlbumsCheckedOut(Connection conn) {
        try {
            Scanner keyboard = new Scanner(System.in);
            System.out.println(
                    "What is the Library Card Number for this report?");
            int cardNumb = keyboard.nextInt();
            keyboard.nextLine();

            PreparedStatement stmt = conn.prepareStatement(reportTwo);
            stmt.setInt(1, cardNumb);

            ResultSet rs = stmt.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                String value = rsmd.getColumnName(i);
                System.out.print(value);
                if (i < columnCount) {
                    System.out.print(",  ");
                }
            }
            System.out.print("\n");
            while (rs.next()) {
                for (int i = 1; i <= columnCount; i++) {
                    String columnValue = rs.getString(i);
                    System.out.print(columnValue);
                    if (i < columnCount) {
                        System.out.print(",  ");
                    }
                }
                System.out.print("\n");
            }

            keyboard.close();

        } catch (SQLException e) {
            System.out.println("Error when trying to execute report");
            System.out.println(e.getMessage());
        }
    }

    private static void popularActor(Connection conn) {
        try {
            Scanner keyboard = new Scanner(System.in);
            System.out.println(
                    "What is the Library Card Number for this report?");
            int cardNumb = keyboard.nextInt();
            keyboard.nextLine();

            PreparedStatement stmt = conn.prepareStatement(reportTwo);
            stmt.setInt(1, cardNumb);

            ResultSet rs = stmt.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                String value = rsmd.getColumnName(i);
                System.out.print(value);
                if (i < columnCount) {
                    System.out.print(",  ");
                }
            }
            System.out.print("\n");
            while (rs.next()) {
                for (int i = 1; i <= columnCount; i++) {
                    String columnValue = rs.getString(i);
                    System.out.print(columnValue);
                    if (i < columnCount) {
                        System.out.print(",  ");
                    }
                }
                System.out.print("\n");
            }

            keyboard.close();

        } catch (SQLException e) {
            System.out.println("Error when trying to execute report");
            System.out.println(e.getMessage());
        }
    }

    private static void patronMostVideos(Connection conn) {
        try {
            PreparedStatement stmt = conn.prepareStatement(reportFive);

            ResultSet rs = stmt.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                String value = rsmd.getColumnName(i);
                System.out.print(value);
                if (i < columnCount) {
                    System.out.print(",  ");
                }
            }
            System.out.print("\n");
            while (rs.next()) {
                for (int i = 1; i <= columnCount; i++) {
                    String columnValue = rs.getString(i);
                    System.out.print(columnValue);
                    if (i < columnCount) {
                        System.out.print(",  ");
                    }
                }
                System.out.print("\n");
            }

        } catch (SQLException e) {
            System.out.println("Error when trying to execute report");
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) {
        Connection conn = initializeDB(DATABASE);
        //sqlQuery(conn, sqlStatement);
        //int response = 1;
        Scanner keyboard = new Scanner(System.in);

        //while (response <= 5 && response > 0) {
        System.out.println(
                "Hello library user!\nPlease enter a number corresponding to one of the following options: \n1. Search\n2. Add New Records\n3. Order Items\n4. Edit Records\n5. Useful Reports");
        int response = keyboard.nextInt();
        keyboard.nextLine();

        if (response == 1) {
            String optionResponse = "";
            while (!(optionResponse.equals("a")
                    || optionResponse.equals("b"))) {
                System.out.println(
                        "Would you like to search:\na. Artist\nb. Track");
                optionResponse = keyboard.nextLine();
            }
            if (optionResponse.equals("a")) {
                sqlQuery(conn, selectArtistStatement);
            } else { //Would be where to search for Track

            }
        } else if (response == 2) {
            String optionResponse = "";
            while (!(optionResponse.equals("a")
                    || optionResponse.equals("b"))) {
                System.out
                        .println("Would you like to add:\na. Artist\nb. Track");
                optionResponse = keyboard.nextLine();
            }
            if (optionResponse.equals("a")) {
                sqlAddArtist(conn);
            } else { //Would be where to add a Track

            }
        } else if (response == 3) {
            String optionResponse = "";
            while (!(optionResponse.equals("a")
                    || optionResponse.equals("b"))) {
                System.out.println(
                        "Would you like to :\na. Order a Movie\nb. Activate item recieved");
                optionResponse = keyboard.nextLine();
            }
            if (optionResponse.equals("a")) {
                sqlOrderMovie(conn);
            } else {

            }
        } else if (response == 4) {
            String optionResponse = "";
            while (!(optionResponse.equals("a"))) {
                System.out.println("Would you like to edit:\na. Artist");
                optionResponse = keyboard.nextLine();
            }
            sqlEditArtist(conn);
        } else if (response == 5) {
            String optionResponse = "";
            while (!(optionResponse.equals("a") || optionResponse.equals("b")
                    || optionResponse.equals("c") || optionResponse.equals("d")
                    || optionResponse.equals("e"))) {
                System.out.println(
                        "Would you like to see :\na. Tracks by ARTIST released before YEAR\nb. Number of albums checked out by a single patron\nc. Most popular actor in the database\nd. Most listened to artist in the database\ne. Patron who has checked out the most videos");
                optionResponse = keyboard.nextLine();
            }
            if (optionResponse.equals("a")) {
                tracksByArtist(conn);
            } else if (optionResponse.equals("b")) {
                numberAlbumsCheckedOut(conn);
            } else if (optionResponse.equals("c")) {

            } else if (optionResponse.equals("d")) {

            } else {
                patronMostVideos(conn);
            }
        } else {
            System.out.println("Thank you for using the library.");
        }
        //}
        keyboard.close();
    }
}
